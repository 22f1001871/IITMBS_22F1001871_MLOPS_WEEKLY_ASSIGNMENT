import argparse
import json

def load(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--v1", required=True)
    p.add_argument("--v2", required=True)
    a = p.parse_args()
    x, y = load(a.v1), load(a.v2)

    print("| Metric | v1 Raw | v2 Natural Language |")
    print("|---|---:|---:|")
    print(f"| Accuracy | {x['accuracy']:.4f} | {y['accuracy']:.4f} |")
    print(f"| Format compliance | {x['format_compliance_rate']:.4f} | {y['format_compliance_rate']:.4f} |")
    for label in ("setosa","versicolor","virginica"):
        print(f"| {label} precision | {x['per_class'][label]['precision']:.4f} | {y['per_class'][label]['precision']:.4f} |")
        print(f"| {label} recall | {x['per_class'][label]['recall']:.4f} | {y['per_class'][label]['recall']:.4f} |")

if __name__ == "__main__":
    main()
