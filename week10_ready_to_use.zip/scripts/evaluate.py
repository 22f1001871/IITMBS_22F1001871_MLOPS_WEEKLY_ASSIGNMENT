import argparse
import json
import os
from pathlib import Path
import pandas as pd
from google import genai
from google.genai import types
from sklearn.metrics import accuracy_score, precision_recall_fscore_support

LABELS = ["setosa", "versicolor", "virginica"]

def prompt_for(row, version):
    if version == "v1":
        return (
            f"sepal_length: {row['sepal_length']}, "
            f"sepal_width: {row['sepal_width']}, "
            f"petal_length: {row['petal_length']}, "
            f"petal_width: {row['petal_width']}"
        )
    return (
        f"A flower specimen has a sepal length of {row['sepal_length']} cm, "
        f"sepal width of {row['sepal_width']} cm, "
        f"petal length of {row['petal_length']} cm, "
        f"and petal width of {row['petal_width']} cm. "
        f"Identify the iris species."
    )

def parse_response(raw, version):
    raw = (raw or "").strip()
    if version == "v1":
        return (raw, True) if raw in LABELS else (None, False)

    expected = {
        "This is Iris setosa.": "setosa",
        "This is Iris versicolor.": "versicolor",
        "This is Iris virginica.": "virginica",
    }
    return (expected[raw], True) if raw in expected else (None, False)

def call_model(client, model, prompt):
    response = client.models.generate_content(
        model=model,
        contents=prompt,
        config=types.GenerateContentConfig(
            temperature=0.0,
            max_output_tokens=32,
            thinking_config=types.ThinkingConfig(thinking_budget=0),
        ),
    )
    return response.text.strip() if response.text else ""

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--test", default="data/test.csv")
    p.add_argument("--model", required=True)
    p.add_argument("--version", choices=["v1","v2"], required=True)
    p.add_argument("--output", default="results/evaluation.json")
    a = p.parse_args()

    project = os.getenv("GOOGLE_CLOUD_PROJECT")
    location = os.getenv("GOOGLE_CLOUD_LOCATION", "us-central1")
    if not project:
        raise ValueError("Set GOOGLE_CLOUD_PROJECT.")

    client = genai.Client(vertexai=True, project=project, location=location)
    df = pd.read_csv(a.test)
    rows = []

    for i, row in df.iterrows():
        actual = str(row["species"]).strip().lower()
        raw = call_model(client, a.model, prompt_for(row, a.version))
        prediction, compliant = parse_response(raw, a.version)
        rows.append({
            "index": int(i),
            "actual": actual,
            "raw_response": raw,
            "prediction": prediction,
            "format_compliant": compliant,
            "correct": prediction == actual,
        })

    y_true = [r["actual"] for r in rows]
    y_pred = [r["prediction"] if r["prediction"] in LABELS else "__invalid__" for r in rows]
    accuracy = accuracy_score(y_true, y_pred)
    precision, recall, f1, support = precision_recall_fscore_support(
        y_true, y_pred, labels=LABELS, zero_division=0
    )
    compliance = sum(r["format_compliant"] for r in rows) / len(rows)

    result = {
        "model": a.model,
        "version": a.version,
        "test_samples": len(rows),
        "accuracy": float(accuracy),
        "format_compliance_rate": float(compliance),
        "per_class": {
            label: {
                "precision": float(precision[i]),
                "recall": float(recall[i]),
                "f1": float(f1[i]),
                "support": int(support[i]),
            }
            for i, label in enumerate(LABELS)
        },
        "predictions": rows,
    }

    Path(a.output).parent.mkdir(parents=True, exist_ok=True)
    with open(a.output, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)

    print(json.dumps({
        "accuracy": result["accuracy"],
        "format_compliance_rate": result["format_compliance_rate"],
        "per_class": result["per_class"],
    }, indent=2))

if __name__ == "__main__":
    main()
