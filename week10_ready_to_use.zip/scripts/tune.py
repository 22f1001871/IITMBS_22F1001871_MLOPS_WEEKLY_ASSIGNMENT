import argparse
import os
import time
import vertexai
from vertexai.tuning import sft

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--version", choices=["v1","v2"], required=True)
    p.add_argument("--train-gcs", required=True)
    p.add_argument("--validation-gcs", required=True)
    p.add_argument("--output-gcs", required=True)
    p.add_argument("--display-name", required=True)
    p.add_argument("--project", default=os.getenv("GOOGLE_CLOUD_PROJECT"))
    p.add_argument("--location", default=os.getenv("GOOGLE_CLOUD_LOCATION", "us-central1"))
    p.add_argument("--base-model", default=os.getenv("GEMINI_BASE_MODEL", "gemini-2.5-flash"))
    p.add_argument("--epochs", type=int, default=5)
    p.add_argument("--learning-rate-multiplier", type=float, default=1.0)
    p.add_argument("--adapter-size", type=int, default=8)
    a = p.parse_args()

    if not a.project:
        raise ValueError("Set GOOGLE_CLOUD_PROJECT or pass --project.")

    vertexai.init(project=a.project, location=a.location)

    job = sft.train(
        source_model=a.base_model,
        train_dataset=a.train_gcs,
        validation_dataset=a.validation_gcs,
        tuned_model_display_name=a.display_name,
        epochs=a.epochs,
        learning_rate_multiplier=a.learning_rate_multiplier,
        adapter_size=a.adapter_size,
    )

    print("Tuning job submitted:", job.name)
    while not job.has_ended:
        time.sleep(60)
        job.refresh()
        print("State:", job.state)

    print("Final state:", job.state)
    print("Tuned model:", job.tuned_model_name)
    print("Tuned endpoint:", job.tuned_model_endpoint_name)

if __name__ == "__main__":
    main()
